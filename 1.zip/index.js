import React from "react";
import { AppRegistry } from "react-360";
import Main from "./src/components/main";

export default class Hello360 extends React.Component {
  render() {
    return <Main />;
  }
}

AppRegistry.registerComponent("Hello360", () => Hello360);
