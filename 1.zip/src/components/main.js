import React from "react";
import { asset, View, Image } from "react-360";
import styles from "../styles/styles";
import Top from "../components/top";

export default Main = () => {
  return (
    <View style={styles.panel}>
      <Top />
    </View>
  );
};
