import React from "react";
import { View } from "react-360";
import styles from "../styles/styles";
import NavButton from "../components/NavButton";
import MenuButton from "../components/MenuButton";
import * as Animatable from "react-native-animatable";

export default class Navbar extends React.Component {
  constructor() {
    super();
    this.state = { display: false, other: "lala" };
  }
  setDisplay(setState) {
    this.setState({ ...this.state, display: setState });
  }
  render() {
    return (
      <View style={styles.navbar}>
        <MenuButton
          name="menu"
          action={this.setDisplay.bind(this)}
          state={this.state.display}
        />
        <Animatable.View
          style={styles.navbar}
          animation={this.state.display ? "fadeInLeft" : "fadeOutLeft"}
          easing="linear"
        >
          <NavButton name="button two" />
          <NavButton name="button tree" />
          <NavButton name="button four" />
          <NavButton name="button five" />
          <NavButton name="button six" />
        </Animatable.View>
      </View>
    );
  }
}
