import React from "react";
import { Text, VrButton } from "react-360";
import styles from "../styles/styles";

export default NavButton = ({ name }) => {
  return (
    <VrButton style={styles.button}>
      <Text>{name}</Text>
    </VrButton>
  );
};
