import React from "react";
import { asset, Text, VrButton, Image } from "react-360";
import styles from "../styles/styles";
import * as Animatable from "react-native-animatable";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faAd } from '@fortawesome/free-solid-svg-icons'

export default MenuButton = ({ name, action, state }) => {
  return (
    <Animatable.View animation="bounceInDown" easing="ease-in-quad">
      <VrButton onClick={() => action(!state)}>
        {/* <Text>{name}</Text> */}
        <Image style={styles.menuButton} source={asset("menu.png")} />
        {/* <FontAwesomeIcon icon={faAd}/> */}
      </VrButton>
    </Animatable.View>
  );
};
