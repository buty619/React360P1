import React from "react";
import { View } from "react-360";
import styles from "../styles/styles";
import Navbar from "../components/Navbar";

export default Top = () => {
  return (
    <View style={styles.top}>
      <Navbar />
    </View>
  );
};
